import re

with open('e:/KFUPM/Dr zain/my-web-page/research/Research.html', 'r', encoding='utf-8') as f:
    html = f.read()

nav = re.search(r'<header class="navbar">.*?</header>', html, re.DOTALL).group(0)
footer = re.search(r'<footer>.*?</footer>', html, re.DOTALL).group(0)

# Replace 'active' class from research link to profile link
nav = nav.replace('data-nav="research" class="active"', 'data-nav="research"')
nav = nav.replace('data-nav="personal"', 'data-nav="personal" class="active"')

new_html = f'''<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - Prof. Zain H. Yamani</title>
    <meta name="theme-color" content="#277E3C">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Outfit:wght@500;600;700;800&family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer">
    <link rel="stylesheet" href="../index.css">
    <script src="../site.js" defer></script>
</head>
<body data-page="personal">
    <div class="scroll-progress"></div>
    {nav}

    <main>
        <section class="page-hero">
            <canvas id="hero-canvas" class="page-hero-canvas" data-tone="light" aria-hidden="true"></canvas>
            <div class="container">
                <div class="crumbs" data-reveal="down"><a href="../index.html"><i class="fa-solid fa-house"></i> Home</a><i class="fa-solid fa-chevron-right" style="font-size:.7rem"></i><span>Profile</span></div>
                <h1 data-reveal="up">Prof. Zain H. Yamani</h1>
                <p data-reveal="up" style="--d:.1s">Professor of Physics · Educator · Researcher</p>
                <div class="hero-actions" data-reveal="up" style="--d:.2s">
                    <a href="vitae-8-2012%20(Zain%20Yamani).pdf" class="btn btn-light"><i class="fa-solid fa-file-pdf"></i> Download CV</a>
                </div>
            </div>
        </section>

        <section class="section">
            <div class="container">
                <div class="section-head">
                    <span class="eyebrow"><i class="fa-solid fa-id-card"></i> Personal Information</span>
                    <h2>About <span class="hl">Prof. Yamani</span></h2>
                </div>
                <div class="grid grid-2" data-stagger=".12">
                    <div class="card feature-card" data-reveal="up">
                        <div class="icon-badge"><i class="fa-solid fa-user"></i></div>
                        <h3>Personal Details</h3>
                        <ul class="check-list" style="margin-top: 1rem;">
                            <li><i class="fa-solid fa-calendar"></i> <strong>Date of Birth:</strong> 25-3-1389 H / 6-10-1969</li>
                            <li><i class="fa-solid fa-globe"></i> <strong>Nationality:</strong> Saudi Arabian</li>
                            <li><i class="fa-solid fa-people-roof"></i> <strong>Family:</strong> Married, three daughters (Asma, Sarah, Mariam) and two sons (Al-Hassan, Al-Hussain)</li>
                            <li><i class="fa-solid fa-heart"></i> <strong>Interests:</strong> Popularizing Sciences, Teaching, Research, Reading, Social Services, Table Tennis</li>
                        </ul>
                    </div>
                    
                    <div class="card feature-card" data-reveal="up">
                        <div class="icon-badge gold"><i class="fa-solid fa-graduation-cap"></i></div>
                        <h3>Education</h3>
                        <ul class="check-list" style="margin-top: 1rem;">
                            <li><i class="fa-solid fa-certificate"></i> <strong>Ph.D. Physics</strong> (1999) - University of Illinois at Urbana-Champaign</li>
                            <li><i class="fa-solid fa-certificate"></i> <strong>Masters Physics</strong> (1995) - University of Illinois at Urbana-Champaign</li>
                            <li><i class="fa-solid fa-certificate"></i> <strong>Masters Physics</strong> (1993) - KFUPM</li>
                            <li><i class="fa-solid fa-certificate"></i> <strong>BSc. Physics</strong> (1991) - KFUPM</li>
                        </ul>
                    </div>
                    
                    <div class="card feature-card" data-reveal="up">
                        <div class="icon-badge gold"><i class="fa-solid fa-award"></i></div>
                        <h3>Vocation & Affiliations</h3>
                        <ul class="check-list" style="margin-top: 1rem;">
                            <li><i class="fa-solid fa-medal" style="color: var(--accent);"></i> <strong>Award:</strong> The King Abdul-Aziz Medal of the First Type (Awarded by King Abdullah)</li>
                            <li><i class="fa-solid fa-briefcase"></i> <strong>Professor:</strong> Physics Dept. KFUPM (Condensed Matter)</li>
                            <li><i class="fa-solid fa-microscope"></i> <strong>Director:</strong> Center of Excellence in Nanotechnology (CENT) @ KFUPM</li>
                            <li><i class="fa-solid fa-users-rectangle"></i> <strong>Board Member:</strong> The Saudi Physics Society (SPS) & Director, Teachers’ Division</li>
                            <li><i class="fa-solid fa-id-badge"></i> <strong>Member:</strong> SPS, APS, AAPT, OSA, ACS, FKF</li>
                        </ul>
                    </div>
                    
                    <div class="card feature-card" data-reveal="up">
                        <div class="icon-badge"><i class="fa-solid fa-address-book"></i></div>
                        <h3>Contact Information</h3>
                        <ul class="check-list" style="margin-top: 1rem;">
                            <li><i class="fa-solid fa-phone"></i> <strong>Office Phone:</strong> (+966) 3-860-4363</li>
                            <li><i class="fa-solid fa-fax"></i> <strong>Office Fax:</strong> (+966) 3-860-7264</li>
                            <li><i class="fa-solid fa-house"></i> <strong>Home Phone/Fax:</strong> (+966) 3-860-6003</li>
                            <li><i class="fa-solid fa-envelope"></i> <strong>Email:</strong> <a href="mailto:zhyamani@kfupm.edu.sa" class="text-link">zhyamani@kfupm.edu.sa</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
    </main>
    
    {footer}
    <button class="back-to-top" id="back-to-top" aria-label="Back to top"><i class="fa-solid fa-arrow-up"></i></button>
</body>
</html>
'''

with open('e:/KFUPM/Dr zain/my-web-page/personal/personal.htm', 'w', encoding='utf-8') as f:
    f.write(new_html)
