import os

root_dir = 'e:/KFUPM/Dr zain/my-web-page'

html_files = []
for dirpath, dirnames, filenames in os.walk(root_dir):
    for filename in filenames:
        if filename.endswith('.html') or filename.endswith('.htm'):
            html_files.append(os.path.join(dirpath, filename))

count = 0
encodings = ['utf-8', 'windows-1256', 'windows-1252', 'latin-1']

for filepath in html_files:
    content = None
    used_enc = None
    for enc in encodings:
        try:
            with open(filepath, 'r', encoding=enc) as f:
                content = f.read()
            used_enc = enc
            break
        except UnicodeDecodeError:
            continue
            
    if content is not None:
        new_content = content.replace('Personal Information.html', 'personal.htm')
        new_content = new_content.replace('Personal%20Information.html', 'personal.htm')
        
        if new_content != content:
            with open(filepath, 'w', encoding=used_enc) as f:
                f.write(new_content)
            count += 1
    else:
        print(f"Failed to read {filepath} with any encoding")

print(f"Updated {count} additional files.")
