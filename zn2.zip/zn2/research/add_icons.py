import re

with open('e:/KFUPM/Dr zain/my-web-page/research/Research.html', 'r', encoding='utf-8') as f:
    content = f.read()

# The team section is bounded by '<!-- ================= TEAM ================= -->' and '<!-- ================= CAPABILITIES ================= -->'
start_idx = content.find('<!-- ================= TEAM ================= -->')
end_idx = content.find('<!-- ================= CAPABILITIES ================= -->')

if start_idx != -1 and end_idx != -1:
    team_section = content[start_idx:end_idx]
    
    social_html = ' <div style="display:inline-flex;gap:0.5rem;margin-left:0.5rem;font-size:1.1rem;"><a href="#" title="Scopus"><i class="fa-solid fa-book-open-reader"></i></a><a href="#" title="Google Scholar"><i class="fa-brands fa-google-scholar"></i></a></div>'
    
    def repl(m):
        return m.group(1) + social_html
    
    updated_team_section = re.sub(r'(<h3>.*?</h3>)', repl, team_section)
    
    new_content = content[:start_idx] + updated_team_section + content[end_idx:]
    
    with open('e:/KFUPM/Dr zain/my-web-page/research/Research.html', 'w', encoding='utf-8') as f:
        f.write(new_content)
    print("Updated team section successfully.")
else:
    print("Could not find team section boundaries.")
