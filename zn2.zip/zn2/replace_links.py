import os
import re

root_dir = 'e:/KFUPM/Dr zain/my-web-page'

html_files = []
for dirpath, dirnames, filenames in os.walk(root_dir):
    for filename in filenames:
        if filename.endswith('.html') or filename.endswith('.htm'):
            html_files.append(os.path.join(dirpath, filename))

count = 0
for filepath in html_files:
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
            
        new_content = content.replace('Personal Information.html', 'personal.htm')
        new_content = new_content.replace('Personal%20Information.html', 'personal.htm')
        
        if new_content != content:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(new_content)
            count += 1
    except Exception as e:
        print(f"Error processing {filepath}: {e}")

print(f"Updated {count} files.")
