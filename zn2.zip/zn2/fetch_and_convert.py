import urllib.request
import os

template = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title} - Dr. Zain Yamani</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{css_path}">
    <style>
        .page-content {{
            padding: 4rem 2rem;
            max-width: 800px;
            margin: 0 auto;
            background: var(--bg-surface);
            border-radius: 12px;
            box-shadow: var(--shadow-md);
            margin-top: 3rem;
            margin-bottom: 3rem;
        }}
        .page-content h1, .page-content h2, .page-content b font {{
            color: var(--primary-color) !important;
            font-size: 2.5rem;
            margin-bottom: 2rem;
            text-align: center;
            display: block;
        }}
        .page-content p {{
            margin-bottom: 1.5rem;
            font-size: 1.1rem;
            color: var(--text-main);
        }}
        .page-content a {{
            color: var(--primary-color);
            font-weight: 500;
        }}
        .page-content a:hover {{
            text-decoration: underline;
        }}
        .page-content font {{
            color: inherit !important;
            font-family: inherit !important;
            size: inherit !important;
        }}
        .page-content span {{
            color: inherit !important;
            font-family: inherit !important;
            font-size: inherit !important;
        }}
        .page-content img {{
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            margin: 1rem 0;
            box-shadow: var(--shadow-sm);
        }}
        .page-content [style] {{
            color: inherit !important;
            font-family: inherit !important;
            text-align: center;
        }}
    </style>
</head>
<body>
    <header class="navbar">
        <div class="container nav-container">
            <div class="logo">
                <a href="{root_path}index.html">Dr. Zain Yamani</a>
            </div>
            <nav>
                <ul class="nav-links">
                    <li><a href="{root_path}teaching/Teaching.html">Teaching</a></li>
                    <li><a href="{root_path}research/Research.html">Research</a></li>
                    <li><a href="{root_path}presentations/Presentations.html">Presentations</a></li>
                    <li><a href="{root_path}personal/Personal Information.html">Personal Info</a></li>
                    <li><a href="{root_path}interesting link/interesting_physics_links.html">Links</a></li>
                    <li><a href="{root_path}Arabic/Arabic.html" class="btn-arabic">عربي</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main class="container">
        <div class="page-content">
            {content}
        </div>
    </main>

    <footer>
        <div class="container footer-container">
            <p>&copy; 2026 Dr. Zain Yamani. All Rights Reserved.</p>
            <p><a href="http://www.kfupm.edu.sa">King Fahd University of Petroleum and Minerals (KFUPM)</a></p>
        </div>
    </footer>
</body>
</html>
"""

base_url = "https://faculty.kfupm.edu.sa/PHYS/zhyamani/"

pages_to_convert = [
    ("research/Research.html", "Research", "../index.css", "../"),
    ("presentations/Presentations.html", "Presentations", "../index.css", "../"),
    ("personal/Personal%20Information.html", "Personal Information", "../index.css", "../"),
    ("interesting%20link/interesting_physics_links.html", "Interesting Links", "../index.css", "../"),
    ("Arabic/Arabic.html", "Arabic", "../index.css", "../")
]

for url_path, title, css_path, root_path in pages_to_convert:
    try:
        url = base_url + url_path
        print(f"Fetching {url}")
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req) as response:
            content_bytes = response.read()
            content = content_bytes.decode('windows-1256', errors='replace')
            
        # We find the top boundary: 'modified-Dr.-Zain-30-1_11.gif'
        top_idx = content.find('modified-Dr.-Zain-30-1_11.gif')
        if top_idx == -1:
            print(f"Failed to find top boundary in {url_path}")
            continue
            
        # The content actually starts after the </TR> of that row
        start_idx = content.find('</TR>', top_idx)
        if start_idx == -1:
            start_idx = top_idx + 30 # fallback
        else:
            start_idx += 5
            
        # The content ends at the row with drZainSite_13.gif
        bottom_idx = content.find('drZainSite_13.gif', start_idx)
        if bottom_idx == -1:
            print(f"Failed to find bottom boundary in {url_path}")
            continue
            
        # Find the preceding <TR> to cleanly cut it
        end_idx = content.rfind('<TR>', start_idx, bottom_idx)
        if end_idx == -1:
            end_idx = bottom_idx
            
        extracted_content = content[start_idx:end_idx]
        
        # remove surrounding <TD COLSPAN=7> if it exists
        extracted_content = extracted_content.replace('<TD COLSPAN=7>', '')
        extracted_content = extracted_content.replace('</TD>', '')
        
        # Write to local file
        import urllib.parse
        local_path = urllib.parse.unquote(url_path)
        
        new_html = template.format(title=title, content=extracted_content.strip(), css_path=css_path, root_path=root_path)
        
        with open(local_path, "w", encoding="utf-8") as f:
            f.write(new_html)
        print(f"Successfully converted {local_path}")
            
    except Exception as e:
        print(f"Error fetching {url_path}: {e}")
