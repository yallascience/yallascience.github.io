vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|04 Mar 2004 05:18:08 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|academia/102/physics-102.htm
vti_syncwith_faculty.kfupm.edu.sa\:80/phys/zhyamani:TR|04 Mar 2004 05:18:07 -0000
vti_syncwith_www.kfupm.edu.sa\:80/cent:TR|04 Mar 2004 05:18:07 -0000
vti_modifiedby:SR|JMY\\melse
vti_cacheddtm:TX|04 Mar 2004 05:18:08 -0000
vti_filesize:IR|16040
