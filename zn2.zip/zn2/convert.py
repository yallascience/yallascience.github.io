import os
import re

template = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title} - Dr. Zain Yamani</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{css_path}">
    <style>
        .page-content {{
            padding: 4rem 2rem;
            max-width: 800px;
            margin: 0 auto;
            background: var(--bg-surface);
            border-radius: 12px;
            box-shadow: var(--shadow-md);
            margin-top: 3rem;
            margin-bottom: 3rem;
        }}
        .page-content h1, .page-content h2, .page-content b font {{
            color: var(--primary-color) !important;
            font-size: 2.5rem;
            margin-bottom: 2rem;
            text-align: center;
            display: block;
        }}
        .page-content p {{
            margin-bottom: 1.5rem;
            font-size: 1.1rem;
            color: var(--text-main);
        }}
        .page-content a {{
            color: var(--primary-color);
            font-weight: 500;
        }}
        .page-content a:hover {{
            text-decoration: underline;
        }}
        .page-content font {{
            color: inherit !important;
            font-family: inherit !important;
            size: inherit !important;
        }}
        .page-content span {{
            color: inherit !important;
            font-family: inherit !important;
            font-size: inherit !important;
        }}
        .page-content img {{
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            margin: 1rem 0;
            box-shadow: var(--shadow-sm);
        }}
        /* overrides for the old inline styles */
        .page-content [style] {{
            color: inherit !important;
            font-family: inherit !important;
            text-align: center;
        }}
    </style>
</head>
<body>
    <header class="navbar">
        <div class="container nav-container">
            <div class="logo">
                <a href="{root_path}index.html">Dr. Zain Yamani</a>
            </div>
            <nav>
                <ul class="nav-links">
                    <li><a href="{root_path}teaching/Teaching.html">Teaching</a></li>
                    <li><a href="{root_path}research/Research.html">Research</a></li>
                    <li><a href="{root_path}presentations/Presentations.html">Presentations</a></li>
                    <li><a href="{root_path}personal/Personal Information.html">Personal Info</a></li>
                    <li><a href="{root_path}interesting link/interesting_physics_links.html">Links</a></li>
                    <li><a href="{root_path}Arabic/Arabic.html" class="btn-arabic">عربي</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main class="container">
        <div class="page-content">
            {content}
        </div>
    </main>

    <footer>
        <div class="container footer-container">
            <p>&copy; 2026 Dr. Zain Yamani. All Rights Reserved.</p>
            <p><a href="http://www.kfupm.edu.sa">King Fahd University of Petroleum and Minerals (KFUPM)</a></p>
        </div>
    </footer>
</body>
</html>
"""

pages_to_convert = [
    ("teaching/Teaching.html", "Teaching", "../index.css", "../"),
    ("research/Research.html", "Research", "../index.css", "../"),
    ("presentations/Presentations.html", "Presentations", "../index.css", "../"),
    ("personal/Personal Information.html", "Personal Information", "../index.css", "../"),
    ("interesting link/interesting_physics_links.html", "Interesting Links", "../index.css", "../"),
    ("Arabic/Arabic.html", "Arabic", "../index.css", "../")
]

for file_path, title, css_path, root_path in pages_to_convert:
    if os.path.exists(file_path):
        with open(file_path, "r", encoding="windows-1256", errors="replace") as f:
            content = f.read()
            
        # extract content between <TR><TD COLSPAN=7>...modified-Dr.-Zain-30-1_11.gif... and the footer drZainSite_13.gif
        match = re.search(r'modified-Dr.-Zain-30-1_11\.gif.*?ALT="">.*?</TD>\s*</TR>\s*<TR>\s*<TD COLSPAN=7>(.*?)</TD>\s*</TR>\s*<TR>\s*<TD COLSPAN=7>\s*<IMG SRC=".*?drZainSite_13\.gif"', content, re.DOTALL | re.IGNORECASE)
        
        if not match:
            # Maybe the structure is slightly different
            match = re.search(r'modified-Dr.-Zain-30-1_11\.gif.*?>(.*?)<IMG SRC=".*?drZainSite_13\.gif"', content, re.DOTALL | re.IGNORECASE)
            
        if match:
            extracted_content = match.group(1).strip()
            
            # Remove any leftover <TD COLSPAN=7> tag and </TD> that might be present at the boundaries
            extracted_content = re.sub(r'^</?TD.*?>', '', extracted_content)
            extracted_content = re.sub(r'</?TR.*?>', '', extracted_content)
            
            # Remove the "back to home-page" link
            extracted_content = re.sub(r'<p.*?>.*?back\s*to\s*home-page.*?</p>', '', extracted_content, flags=re.DOTALL|re.IGNORECASE)
            
            new_html = template.format(title=title, content=extracted_content, css_path=css_path, root_path=root_path)
            
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(new_html)
            print(f"Converted {file_path}")
        else:
            print(f"Could not extract content for {file_path}")
    else:
        print(f"File not found: {file_path}")
